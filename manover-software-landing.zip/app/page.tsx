import { HeroSection } from "@/components/hero-section"
import { PainSection } from "@/components/pain-section"
import { ForYouSection } from "@/components/for-you-section"
import { IntentSection } from "@/components/intent-section"
import { ContactSection } from "@/components/contact-section"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <HeroSection />
      <PainSection />
      <ForYouSection />
      <IntentSection />
      <ContactSection />
      <Footer />
    </main>
  )
}
