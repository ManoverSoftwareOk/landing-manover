import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const faqs = [
  {
    question: "¿Tengo que instalar algo en mi computadora?",
    answer: "No, no hace falta instalar nada. Podés ver todo desde tu celular o cualquier dispositivo con internet.",
  },
  {
    question: "¿Qué pasa si ya uso Excel?",
    answer:
      "Mucho mejor. Nosotros vinculamos el sistema para que la información se vuelque automáticamente en una hoja de cálculo simple, pero mucho más ordenada y automatizada.",
  },
  {
    question: "¿Tengo que cambiar mi número de WhatsApp?",
    answer:
      "No, usás el mismo número de siempre. Lo que hacemos es sumar una herramienta para que el teléfono trabaje para vos y no al revés.",
  },
  {
    question: "¿Es difícil de usar?",
    answer:
      "Para nada. Está diseñado para que cualquier persona que sepa mandar un mensaje de texto pueda manejarlo sin problemas.",
  },
]

export function FAQSection() {
  return (
    <section id="faq" className="py-20 md:py-28 bg-card">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Preguntas frecuentes</h2>
        </div>

        <div className="max-w-2xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border-border">
                <AccordionTrigger className="text-left text-foreground hover:text-foreground/80 font-medium">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  )
}
