import { Clock, Table2, CreditCard, Mail } from "lucide-react"

const problems = [
  {
    icon: Clock,
    title: "Mensajes perdidos",
    description:
      "Se te pasan mensajes de posibles huéspedes porque estás limpiando una habitación o haciendo las compras.",
  },
  {
    icon: Table2,
    title: "Excel desordenado",
    description: "Tu planilla de Excel es un lío y tenés miedo de anotar mal una fecha y terminar con un sobrecupo.",
  },
  {
    icon: CreditCard,
    title: "Comisiones altas",
    description:
      "Sentís que Booking se queda con gran parte de tu ganancia en comisiones, pero no sabés cómo vender por tu cuenta.",
  },
  {
    icon: Mail,
    title: "Confirmaciones manuales",
    description: "Pasás horas enviando manualmente los datos de transferencia y confirmando cada pago.",
  },
]

export function ProblemSection() {
  return (
    <section id="problema" className="py-20 md:py-28 bg-card">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">El problema de gestionar todo a mano</h2>
          <p className="text-lg text-muted-foreground">
            Sabemos que llevar adelante un alojamiento pequeño en Argentina es un trabajo de tiempo completo. Es muy
            común que te sientas identificado con estas situaciones:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {problems.map((problem, index) => (
            <div key={index} className="flex gap-4 p-6 rounded-xl bg-background border border-border">
              <div className="flex-shrink-0 h-12 w-12 rounded-lg bg-secondary flex items-center justify-center">
                <problem.icon className="h-6 w-6 text-foreground" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-2">{problem.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{problem.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
