import { Moon, Landmark, LayoutDashboard, Zap } from "lucide-react"

const benefits = [
  {
    icon: Moon,
    title: "Ventas mientras dormís",
    description: "Tu sistema recibe consultas y concreta reservas aunque sea de madrugada.",
  },
  {
    icon: Landmark,
    title: "Independencia de las plataformas",
    description: "Empezá a recibir reservas directas y ahorrate las comisiones de terceros.",
  },
  {
    icon: LayoutDashboard,
    title: "Todo organizado en un solo lugar",
    description: "Vas a ver tus ingresos y disponibilidad de forma clara y sencilla, sin errores de anotación.",
  },
  {
    icon: Zap,
    title: "Atención inmediata",
    description:
      "El cliente recibe una respuesta en el segundo exacto en que escribe, aumentando las chances de que elija tu alojamiento.",
  },
]

export function BenefitsSection() {
  return (
    <section id="beneficios" className="py-20 md:py-28 bg-card">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Beneficios concretos para tu negocio</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {benefits.map((benefit, index) => (
            <div key={index} className="flex gap-4 p-6">
              <div className="flex-shrink-0 h-12 w-12 rounded-lg bg-accent flex items-center justify-center">
                <benefit.icon className="h-6 w-6 text-accent-foreground" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-2 text-lg">{benefit.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{benefit.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
