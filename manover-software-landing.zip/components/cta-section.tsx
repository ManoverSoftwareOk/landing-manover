import { Button } from "@/components/ui/button"
import { MessageCircle } from "lucide-react"

export function CTASection() {
  const whatsappLink = "https://wa.me/5491100000000?text=Hola,%20quiero%20una%20asesoría%20sobre%20Manover%20Software"

  return (
    <section className="py-20 md:py-28">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center bg-primary rounded-2xl p-10 md:p-16">
          <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
            ¿Listo para simplificar tu negocio?
          </h2>
          <p className="text-lg text-primary-foreground/80 mb-8">
            Hacé clic acá para hablar con nosotros y ver cómo podemos ayudarte.
          </p>
          <Button asChild size="lg" className="bg-card hover:bg-card/90 text-foreground px-8 py-6 text-base">
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
              <MessageCircle className="h-5 w-5" />
              Quiero recibir una asesoría por WhatsApp
            </a>
          </Button>
        </div>
      </div>
    </section>
  )
}
