"use client"

import React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { MessageCircle, Send } from "lucide-react"

const WHATSAPP_NUMBER = "5491100000000"

export function ContactSection() {
  const [formData, setFormData] = useState({
    nombre: "",
    whatsapp: "",
    hotel: "",
  })
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    const message = encodeURIComponent(
      `Hola! Soy ${formData.nombre} de ${formData.hotel}. Me interesa hablar sobre el problema de responder mensajes. Mi WhatsApp es ${formData.whatsapp}`
    )
    
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, "_blank")
    setSubmitted(true)
  }

  const handleDirectWhatsApp = () => {
    const message = encodeURIComponent("Hola! Me interesa hablar sobre el problema de responder mensajes en mi alojamiento.")
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, "_blank")
  }

  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4 max-w-lg">
        <div className="text-center mb-10">
          <h2 className="text-2xl md:text-3xl font-semibold text-foreground mb-3">
            ¿Te pasa esto en tu hotel?
          </h2>
          <p className="text-muted-foreground">
            Dejanos tus datos y te contactamos para charlar 10 minutos.
          </p>
        </div>

        {!submitted ? (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="nombre">Tu nombre</Label>
              <Input
                id="nombre"
                type="text"
                placeholder="Juan Pérez"
                required
                value={formData.nombre}
                onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                className="h-12"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="whatsapp">Tu WhatsApp</Label>
              <Input
                id="whatsapp"
                type="tel"
                placeholder="+54 9 11 1234-5678"
                required
                value={formData.whatsapp}
                onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                className="h-12"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="hotel">Nombre de tu alojamiento</Label>
              <Input
                id="hotel"
                type="text"
                placeholder="Hotel / Hostel / Cabañas..."
                required
                value={formData.hotel}
                onChange={(e) => setFormData({ ...formData, hotel: e.target.value })}
                className="h-12"
              />
            </div>
            
            <Button 
              type="submit" 
              size="lg" 
              className="w-full h-14 text-base rounded-full mt-4"
            >
              <Send className="mr-2 h-5 w-5" />
              Quiero que me contacten
            </Button>
          </form>
        ) : (
          <div className="text-center py-8 px-6 bg-accent/10 rounded-2xl border border-accent/20">
            <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="h-8 w-8 text-accent" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">
              ¡Gracias por tu interés!
            </h3>
            <p className="text-muted-foreground">
              Te vamos a contactar pronto para coordinar la charla.
            </p>
          </div>
        )}

        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground mb-3">
            ¿Preferís escribirnos directamente?
          </p>
          <Button 
            variant="outline" 
            onClick={handleDirectWhatsApp}
            className="rounded-full bg-transparent"
          >
            <MessageCircle className="mr-2 h-4 w-4" />
            Abrir WhatsApp
          </Button>
        </div>
      </div>
    </section>
  )
}
