"use client"

import { Button } from "@/components/ui/button"
import { MessageCircle } from "lucide-react"

const WHATSAPP_NUMBER = "5491100000000"
const WHATSAPP_MESSAGE = encodeURIComponent("Hola! Me interesa hablar sobre el problema de responder mensajes en mi alojamiento.")

export function HeroSection() {
  const handleClick = () => {
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MESSAGE}`, "_blank")
  }

  return (
    <section className="py-16 md:py-24 lg:py-32">
      <div className="container mx-auto px-4 max-w-3xl text-center">
        <p className="text-sm font-medium text-muted-foreground mb-4 tracking-wide uppercase">
          Manover Software
        </p>
        
        <h1 className="text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground leading-tight text-balance mb-6">
          ¿Perdés reservas por no responder los mensajes a tiempo?
        </h1>
        
        <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto mb-10">
          Ayudamos a hoteles pequeños a responder consultas 24/7 sin estar todo el día pendientes del teléfono.
        </p>
        
        <Button 
          onClick={handleClick}
          size="lg" 
          className="text-base px-8 py-6 rounded-full shadow-md hover:shadow-lg transition-shadow"
        >
          <MessageCircle className="mr-2 h-5 w-5" />
          Quiero hablar 10 minutos
        </Button>
      </div>
    </section>
  )
}
