import { Clock, MessageSquare, DollarSign, Battery } from "lucide-react"

const painPoints = [
  {
    icon: Clock,
    text: "Mensajes que llegan fuera de horario",
  },
  {
    icon: MessageSquare,
    text: "Consultas repetidas todo el día",
  },
  {
    icon: DollarSign,
    text: "Reservas que se pierden por tardar en responder",
  },
  {
    icon: Battery,
    text: "Estrés y falta de descanso",
  },
]

export function PainSection() {
  return (
    <section className="py-16 md:py-20 bg-secondary/50">
      <div className="container mx-auto px-4 max-w-2xl">
        <h2 className="text-2xl md:text-3xl font-semibold text-foreground text-center mb-10">
          Sabemos lo que se siente...
        </h2>
        
        <ul className="space-y-5">
          {painPoints.map((point, index) => (
            <li 
              key={index} 
              className="flex items-start gap-4 bg-card p-5 rounded-xl border border-border"
            >
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <point.icon className="h-5 w-5 text-primary" />
              </div>
              <p className="text-foreground text-lg leading-relaxed pt-1.5">
                {point.text}
              </p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
