import Link from "next/link"
import { Button } from "@/components/ui/button"
import { MessageCircle } from "lucide-react"

export function Header() {
  const whatsappLink = "https://wa.me/5491100000000?text=Hola,%20quiero%20información%20sobre%20Manover%20Software"

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2">
          <span className="text-xl font-bold text-foreground">Manover</span>
        </Link>

        <nav className="hidden md:flex items-center gap-8">
          <Link
            href="#problema"
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            Problema
          </Link>
          <Link
            href="#solucion"
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            Solución
          </Link>
          <Link
            href="#beneficios"
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            Beneficios
          </Link>
          <Link
            href="#faq"
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            FAQ
          </Link>
        </nav>

        <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground">
          <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
            <MessageCircle className="h-4 w-4" />
            <span className="hidden sm:inline">Contactar</span>
          </a>
        </Button>
      </div>
    </header>
  )
}
