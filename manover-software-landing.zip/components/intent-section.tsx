export function IntentSection() {
  return (
    <section className="py-16 md:py-20 bg-secondary/50">
      <div className="container mx-auto px-4 max-w-2xl text-center">
        <h2 className="text-2xl md:text-3xl font-semibold text-foreground mb-6">
          ¿Qué queremos hacer?
        </h2>
        
        <div className="bg-card border border-border rounded-2xl p-8 md:p-10">
          <p className="text-lg md:text-xl text-foreground leading-relaxed">
            No venimos a venderte nada todavía.
          </p>
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mt-4">
            Estamos hablando con dueños de hoteles para entender el problema y construir una solución simple que realmente les sirva.
          </p>
        </div>
      </div>
    </section>
  )
}
